<template>
<div>

    <div class="py-5">
        <h2 class="text-lg md:text-2xl font-semibold text-gray-600 pb-3 pt-10">List of Added Products by Users</h2>

        <div class="table--area shadow rounded-lg  bg-white ">
            <table class="lg:w-full table-auto  overflow-y-scroll">
                <thead>
                    <tr class="text-left">
                        <th class="w-32"></th>
                        <th class="color-blue-500 py-4 px-2 w-48">Name</th>
                        <th class="color-blue-500 py-4 px-2 w-56">Genre</th>
                        <th class="color-blue-500 py-4 px-2 w-56">Release Date</th>
                        <th class="color-blue-500 py-4 px-2">BPM</th>
                        <th class="color-blue-500 py-4 px-2">Basic License</th>
                        <th class="color-blue-500 py-4 px-2">Premium License</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="">
                        <td class="text-gray-600 px-2 py-3"><img src="/images/admin/17.png" width="100" height="100" alt=""></td>
                        <td data-column="Full Name" class="text-gray-600 px-2 py-2">Kings & Queens</td>
                        <td data-column="Email" class="text-gray-600 px-2 py-2">Kings & Queens</td>
                        <td data-column="Producer Name" class="text-gray-600 px-2 py-2">20/08/2020</td>
                        <td data-column="Invite Code" class="text-gray-600 px-2 py-2">12.32</td>
                        <td data-column="Location" class="text-gray-600 px-2 py-2">$78</td>
                        <td data-column="Paypal" class="text-gray-600 px-2 py-2">$78</td>
                        <td class="text-gray-600 px-2 py-2">
                            <img src="/images/admin/img-path-35.svg" width="6" height="21" alt="">
                        </td>
                    </tr>
                    <tr class="">
                        <td class="text-gray-600 px-2 py-3"><img src="/images/admin/19.png" width="100" height="100" alt=""></td>
                        <td data-column="Full Name" class="text-gray-600 px-2 py-2">Kings & Queens</td>
                        <td data-column="Email" class="text-gray-600 px-2 py-2">Kings & Queens</td>
                        <td data-column="Producer Name" class="text-gray-600 px-2 py-2">20/08/2020</td>
                        <td data-column="Invite Code" class="text-gray-600 px-2 py-2">12.32</td>
                        <td data-column="Location" class="text-gray-600 px-2 py-2">$78</td>
                        <td data-column="Paypal" class="text-gray-600 px-2 py-2">$78</td>
                        <td class="text-gray-600 px-2 py-2">
                            <img src="/images/admin/img-path-35.svg" width="6" height="21" alt="">
                        </td>
                    </tr>
                    <tr class="">
                        <td class="text-gray-600 px-2 py-3"><img src="/images/admin/16.png" width="100" height="100" alt=""></td>
                        <td data-column="Full Name" class="text-gray-600 px-2 py-2">Kings & Queens</td>
                        <td data-column="Email" class="text-gray-600 px-2 py-2">Kings & Queens</td>
                        <td data-column="Producer Name" class="text-gray-600 px-2 py-2">20/08/2020</td>
                        <td data-column="Invite Code" class="text-gray-600 px-2 py-2">12.32</td>
                        <td data-column="Location" class="text-gray-600 px-2 py-2">$78</td>
                        <td data-column="Paypal" class="text-gray-600 px-2 py-2">$78</td>
                        <td class="text-gray-600 px-2 py-2">
                            <img src="/images/admin/img-path-35.svg" width="6" height="21" alt="">
                        </td>
                    </tr>
                    <tr class="">
                        <td class="text-gray-600 px-2 py-3"><img src="/images/admin/17.png" width="100" height="100" alt=""></td>
                        <td data-column="Full Name" class="text-gray-600 px-2 py-2">Kings & Queens</td>
                        <td data-column="Email" class="text-gray-600 px-2 py-2">Kings & Queens</td>
                        <td data-column="Producer Name" class="text-gray-600 px-2 py-2">20/08/2020</td>
                        <td data-column="Invite Code" class="text-gray-600 px-2 py-2">12.32</td>
                        <td data-column="Location" class="text-gray-600 px-2 py-2">$78</td>
                        <td data-column="Paypal" class="text-gray-600 px-2 py-2">$78</td>
                        <td class="text-gray-600 px-2 py-2">
                            <img src="/images/admin/img-path-35.svg" width="6" height="21" alt="">
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>

    </div>
</div>
</template>

<script>
export default {
    layout: 'admin',
}
</script>
