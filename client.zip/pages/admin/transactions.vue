<template>
<div>

    <div class="py-5">
        <h2 class="text-lg md:text-2xl font-semibold text-gray-600 pb-3 pt-10">Transaction Logs of Sellers</h2>

        <div class="table--area shadow rounded-lg  bg-white ">
            <table class="lg:w-full table-auto  overflow-y-scroll">
                <thead>
                    <tr class="text-left">
                        <th class="md:w-24 xl:w-10"></th>
                        <th class="color-blue-500 py-3 px-4 w-48">Full Name</th>
                        <th class="color-blue-500 py-3 px-4 w-56">Email</th>
                        <th class="color-blue-500 py-3 px-4 w-56">Producer Name</th>
                        <th class="color-blue-500 py-3 px-4 w-56">Total Earnings </th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="">
                        <td class="text-gray-600 px-4 py-3"><img src="/images/admin/dashboard-img-6.svg" width="25" alt=""></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Oliver</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">developer@gmail.com</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">Tomas</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2"><span class="font-bold">$652</span></td>
                    </tr>
                    <tr class="">
                        <td class="text-gray-600 px-4 py-3"><img src="/images/admin/dashboard-img-6.svg" width="25" alt=""></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Oliver</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">developer@gmail.com</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">Tomas</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2"><span class="font-bold">$652</span></td>
                    </tr>
                    <tr class="">
                        <td class="text-gray-600 px-4 py-3"><img src="/images/admin/dashboard-img-6.svg" width="25" alt=""></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Oliver</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">developer@gmail.com</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">Tomas</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2"><span class="font-bold">$652</span></td>
                    </tr>
                    <tr class="">
                        <td class="text-gray-600 px-4 py-3"><img src="/images/admin/dashboard-img-6.svg" width="25" alt=""></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Oliver</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">developer@gmail.com</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">Tomas</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2"><span class="font-bold">$652</span></td>
                    </tr>
                    <tr class="">
                        <td class="text-gray-600 px-4 py-3"><img src="/images/admin/dashboard-img-6.svg" width="25" alt=""></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Oliver</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">developer@gmail.com</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">Tomas</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2"><span class="font-bold">$652</span></td>
                    </tr>
                    <tr class="">
                        <td class="text-gray-600 px-4 py-3"><img src="/images/admin/dashboard-img-6.svg" width="25" alt=""></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Oliver</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">developer@gmail.com</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">Tomas</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2"><span class="font-bold">$652</span></td>
                    </tr>
                </tbody>
            </table>
        </div>

    </div>
</div>
</template>

<script>
export default {
    middleware: ['auth', 'admin'],
    layout: 'admin',
}
</script>
