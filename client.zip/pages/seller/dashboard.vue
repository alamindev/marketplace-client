<template>
<div>
    <div class="grid lg:grid-cols-3 gap-5 lg:gap-10 py-10">
        <div class="flex items-center justify-between bg-white shadow px-5 py-5 rounded-lg">
            <h2 class="text-gray-700 text-lg">Total Earnings</h2>
            <h1 class="text-3xl font-bold color-blue-500">$675</h1>
        </div>
        <div class="flex items-center justify-between bg-white shadow px-5 py-5 rounded-lg">
            <h2 class="text-gray-700 text-lg">Total Items sold</h2>
            <h1 class="text-3xl font-bold color-blue-500">105</h1>
        </div>
        <div class="flex items-center justify-between bg-white shadow px-5 py-5 rounded-lg">
            <h2 class="text-gray-700 text-lg">Items per order</h2>
            <h1 class="text-3xl font-bold color-blue-500">5</h1>
        </div>
    </div>
    <div class="py-5">
        <h2 class="text-lg font-semibold text-gray-600 pb-3">Earnings</h2>

        <div class="table--area shadow rounded-lg  bg-white ">
            <table class="lg:w-full table-auto  overflow-y-scroll">
                <thead>
                    <tr class="text-left">
                        <th class="color-blue-500 py-3 px-4 "></th>
                        <th class="color-blue-500 py-3 px-4 ">Title</th>
                        <th class="color-blue-500 py-3 px-4  ">Date</th>
                        <th class="color-blue-500 py-3 px-4 ">Total checkout</th>
                        <th class="color-blue-500 py-3 px-4">Buyer name</th>
                        <th class="color-blue-500 py-3  "></th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="">
                        <td></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Music is here</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">04/08/2020</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">$78</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2">Mary</td>
                        <td></td>
                    </tr>
                    <tr class="">
                        <td></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Music is here</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">04/08/2020</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">$78</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2">Mary</td>
                        <td></td>
                    </tr>
                    <tr class="">
                        <td></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Music is here</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">04/08/2020</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">$78</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2">Mary</td>
                        <td></td>
                    </tr>
                    <tr class="">
                        <td></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Music is here</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">04/08/2020</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">$78</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2">Mary</td>
                        <td></td>
                    </tr>
                    <tr class="">
                        <td></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Music is here</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">04/08/2020</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">$78</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2">Mary</td>
                        <td></td>
                    </tr>
                    <tr class="">
                        <td></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Music is here</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">04/08/2020</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">$78</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2">Mary</td>
                        <td></td>
                    </tr>
                    <tr class="">
                        <td></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Music is here</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">04/08/2020</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">$78</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2">Mary</td>
                        <td></td>
                    </tr>
                    <tr class="">
                        <td></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Music is here</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">04/08/2020</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">$78</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2">Mary</td>
                        <td></td>
                    </tr>
                    <tr class="">
                        <td></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Music is here</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">04/08/2020</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">$78</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2">Mary</td>
                        <td></td>
                    </tr>
                    <tr class="">
                        <td></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Music is here</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">04/08/2020</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">$78</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2">Mary</td>
                        <td></td>
                    </tr>
                    <tr class="">
                        <td></td>
                        <td data-column="Full Name" class="text-gray-600 px-4 py-2">Music is here</td>
                        <td data-column="Email" class="text-gray-600 px-4 py-2">04/08/2020</td>
                        <td data-column="Producer Name" class="text-gray-600 px-4 py-2">$78</td>
                        <td data-column="Invite Code" class="text-gray-600 px-4 py-2">Mary</td>
                        <td></td>
                    </tr>

                </tbody>
            </table>
        </div>

    </div>
</div>
</template>

<script>
export default {
    middleware: ['auth', 'seller'],
    layout: 'seller',
}
</script>
